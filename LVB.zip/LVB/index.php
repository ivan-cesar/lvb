<!doctype html>
<html class="no-js" lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- SEO Meta Description -->
    <meta name="description" content="">
    <meta name="author" content="Themeland">

    <!-- Title  -->
    <title>LVB - La Viande Blanche | Manger sain - Manger moins cher!</title>

    <!-- Favicon  -->
    <link rel="icon" href="assets/img/favicon.png">

    <!-- ***** All CSS Files ***** -->

    <!-- Style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css"/>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>


    <!-- Responsive css -->
    <link rel="stylesheet" href="assets/css/responsive.css">

</head>

<body class="blog">
    <!--====== Preloader Area Start ======-->
    <div id="preloader">
        <!-- Digimax Preloader -->
        <div id="digimax-preloader" class="digimax-preloader">
            <!-- Preloader Animation -->
            <div class="preloader-animation">
                <!-- Spinner -->
                <div class="spinner"></div>
                <!-- Loader -->
                <div class="loader">
                    <span data-text-preloader="L" class="animated-letters">L</span>
                    <span data-text-preloader="A" class="animated-letters">A</span>
                    <span data-text-preloader="" class="animated-letters"></span>
                    <span data-text-preloader="V" class="animated-letters">V</span>
                    <span data-text-preloader="I" class="animated-letters">I</span>
                    <span data-text-preloader="A" class="animated-letters">A</span>
                    <span data-text-preloader="N" class="animated-letters">N</span>
                    <span data-text-preloader="D" class="animated-letters">D</span>
                    <span data-text-preloader="E" class="animated-letters">E</span>
                    <span data-text-preloader="" class="animated-letters"></span>
                    <span data-text-preloader="B" class="animated-letters">B</span>
                    <span data-text-preloader="L" class="animated-letters">L</span>
                    <span data-text-preloader="A" class="animated-letters">A</span>
                    <span data-text-preloader="N" class="animated-letters">N</span>
                    <span data-text-preloader="C" class="animated-letters">C</span>
                    <span data-text-preloader="H" class="animated-letters">H</span>
                    <span data-text-preloader="E" class="animated-letters">E</span>
                </div>
                <p class="fw-5 text-center text-uppercase">Chargement</p>
            </div>
            <!-- Loader Animation -->
            <div class="loader-animation">
                <div class="row h-100">
                    <!-- Single Loader -->
                    <div class="col-3 single-loader p-0">
                        <div class="loader-bg"></div>
                    </div>
                    <!-- Single Loader -->
                    <div class="col-3 single-loader p-0">
                        <div class="loader-bg"></div>
                    </div>
                    <!-- Single Loader -->
                    <div class="col-3 single-loader p-0">
                        <div class="loader-bg"></div>
                    </div>
                    <!-- Single Loader -->
                    <div class="col-3 single-loader p-0">
                        <div class="loader-bg"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====== Preloader Area End ======-->

    <!--====== Scroll To Top Area Start ======-->
    <!--<div id="scrollUp" title="Scroll To Top">
        <i class="fas fa-arrow-up"></i>
    </div>-->
    <!--====== Scroll To Top Area End ======-->

    <div class="main overflow-hidden">
        <section id="blog" class="section blog-area ptb_100">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-3">
                        
                            <div class="blog-contact p-3">
                                <!-- Contact Title -->
                                <h3 class="comments-title text-uppercase text-left text-lg-right mb-3">Bienvenue dans le club LVB</h3>
                                <!-- Comment Box -->
                                <div class="contact-box comment-box">
                                    <form method="POST" action="#">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="nom" placeholder="Votre nom" required="required">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="prenoms" placeholder="Votre prénoms" required="required">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <input type="tel" id="phone" class="form-control mozart" name="tel" placeholder="Votre téléphone" required="required">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <span class="form-label" style="font-weight: 400!important;font-size: 14px!important;">Date de naissance</span>
                                                    <input type="date" class="form-control" name="date" placeholder="Entrez votre date de naissance" required="required">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="geo" placeholder="Entrez votre Adresse géographique" required="required">
                                                </div>
                                            </div>
                                              <div class="col-12">
                                                 <div class="form-group">
                                              <select class="form-select form-select-lg mb-3">
                                              <option selected>Choisissez votre statut</option>
                                              <option value="1">Particulier</option>
                                              <option value="2">Professionnel</option>
                                            </select>
                                            </div>
                                            </div>
                                            
                                            <div class="row">
                                                <div class="col-6">
                                                <div class="form-check">
                                                  <input type="radio" class="form-check-input" id="radio3" name="optradio1" value="option3">Payer à la livraison
                                                  <label class="form-check-label" for="radio3"></label>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-check">
                                                  <input type="radio" class="form-check-input" id="radio4" name="optradio1" value="option4" checked>Payer en ligne
                                                  <label class="form-check-label" for="radio4"></label>
                                                </div>
                                            </div>
                                            </div>
                                            <div class="col-12">
                                                <button class="btn btn-bordered mt-3" type="submit">Validez</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                    </div>
                    <div class="col-12 col-lg-9">
                        <!-- Single Blog Details -->
                        <article class="single-blog-details">
                            <!-- Blog Thumb -->
                            <div class="blog-thumb">
                                <a href="#"><img src="assets/img/blog/blog-1.jpg" alt=""></a>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>
        <!-- ***** Blog Area End ***** -->
    </div>


    <!-- ***** All jQuery Plugins ***** -->

    <!-- jQuery(necessary for all JavaScript plugins) -->
    <script src="assets/js/jquery/jquery-3.5.1.min.js"></script>

    <!-- Bootstrap js -->
    <script src="assets/js/bootstrap/popper.min.js"></script>
    <script src="assets/js/bootstrap/bootstrap.min.js"></script>

    <!-- Plugins js -->
    <script src="assets/js/plugins/plugins.min.js"></script>

    <!-- Active js -->
    <script src="assets/js/active.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
<script>
    var validMsg = document.querySelector('#valid-msg');
    var errorMsg = document.querySelector('#error-msg');
    var errorMap = ["Numèro invalide", "Pays invalide"];

   const phoneInputField = document.querySelector("#phone");
   const phoneInput = window.intlTelInput(phoneInputField, {

     onlyCountries:["ci"],
     utilsScript:
       "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
   });
   function getIp(callback) {
 fetch('https://ipinfo.io/json?token=<votre token>', { headers: { 'Accept': 'application/json' }})
   .then((resp) => resp.json())
   .catch(() => {
     return {
       country: 'ci',
     };
   })
   .then((resp) => callback(resp.country));
}
var reset = function(){
    input.classList.remove("error");
    errorMsg.innerHtml = "";
    errorMsg.classList.add("hide");
    validMsg.classList.add("hide");
   //const info = document.querySelector(".alert-info");
}
input.addEventListener('blur',function(){
 reset();
 if(input.value.trim()){
    if(iti.isValidNumber()){
        validMsg.classList.remove("hide");
    }
 }

});

/*function process(event) {
 event.preventDefault();

 const phoneNumber = phoneInput.getNumber();

 info.style.display = "";
 info.innerHTML = `Phone number in E.164 format: <strong>${phoneNumber}</strong>`;
};*/
 </script>
 <style type="text/css">
     .mozart{
        width: 300px!important;
     }
     @media only screen and (max-width: 600px) {
      .mozart{
        width: 445px!important;
       }
    }
 </style>
</html>